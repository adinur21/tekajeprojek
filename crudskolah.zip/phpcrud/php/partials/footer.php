<footer style="position: fixed;bottom: 0;left: 0;width: 100%;text-align: center; padding: 3px; background-color: DarkSalmon; color: white;">
  <p>Code by some Dude in GitHub</p>
  <p>Design and Modified by FlintOnSteel</p>
</footer>
