<html>
    <body>
        
        <div class="container">
            <h1><center>Daftar Siswa</center></h1>
            <h5><center>Project CC RDS</center></h5>
        </div>
    </body>
</html>